package team120;

import battlecode.common.*;

public class Drone extends BaseBot {	
	public Drone(RobotController rc) {
		super(rc);
	}

	public void execute() throws GameActionException {
		// ready to attack
		if (rc.readBroadcast(201) == 1) {
			// attack
			if (getEnemiesInAttackingRange().length > 0) {
				if (rc.isWeaponReady()) {
					attackDrone(getEnemiesInAttackingRange());
				}
			}
			// move
			else if (rc.isCoreReady()) {
				nav.moveTo(theirHQ);
			}
		}
		// swarm
		else {
			MapLocation rallyPoint = new MapLocation( this.myHQ.x + (this.theirHQ.x - this.myHQ.x) / 4,
					this.myHQ.y + (this.theirHQ.y - this.myHQ.y) / 4);

			nav.moveTo(rallyPoint);
		}
	}

	public void attackDrone(RobotInfo[] enemies) throws GameActionException{
		if (enemies.length == 0) {
    		return;
    	}
    	MapLocation toAttack = null;
    	for (RobotInfo info : enemies) {
    		if (info.type == RobotType.MINER)
    			toAttack = info.location;
    		if (info.type == RobotType.MINERFACTORY && toAttack == null)
    			toAttack = info.location;
    		if (info.type == RobotType.BEAVER && toAttack == null)
    			toAttack = info.location;
    	}
    	if (toAttack == null)
    		attackLeastHealthEnemy(enemies);
    	else
    		rc.attackLocation(toAttack);
	}
}