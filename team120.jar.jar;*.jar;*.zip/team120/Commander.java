package team120;

import battlecode.common.*;

public class Commander extends BaseBot {
    public Commander(RobotController rc) {
        super(rc);
    }

    public void execute() throws GameActionException {
        
    }
}