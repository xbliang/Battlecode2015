package team120;

import battlecode.common.*;

import java.util.*;

public class Miner extends BaseBot {

	private MapLocation goAwayFromHere;

	public Miner(RobotController rc) {
		super(rc);
		state = State.MINING;
	}
	
	public MapLocation findNearbyLocWithMostOre() {
		Set<MapLocation> locsInRange = this.getLocsInSensorRange(RobotType.MINER.sensorRadiusSquared);

		double maxOre = 0;
		MapLocation maxOreLocation = rc.getLocation();

		for (MapLocation loc : locsInRange) {
			double thisOre = rc.senseOre(loc);

			if (thisOre > maxOre) {
				maxOre = thisOre;
				maxOreLocation = loc;
			}
		}

		if (maxOre == 0)
			return rc.getLocation();
		return maxOreLocation;
	}

	public void execute() throws GameActionException {
		RobotInfo[] nearbyEnemies = this.getEnemiesInAttackingRange();

		// update state
		if (Clock.getRoundNum() %6 == 0 || rc.senseOre(rc.getLocation()) < 3){
			state = State.MOVING_TOWARD;
		}
		else {
			state = State.MINING;
		}

		if (nearbyEnemies.length > 0) {
			if (shouldRetreat())
				state = State.RETREATING;
			else
				state = State.ATTACKING;
		}

		// do the thing
		if (state == State.RETREATING) {
			tryToMoveAway(getAverageEnemyLocation());
		} else if (state == State.ATTACKING && rc.isWeaponReady()) {
			this.attackLeastHealthEnemy(this.getEnemiesInAttackingRange());
		} else if (rc.isCoreReady()) {
			if (state == State.MINING && rc.canMine() && rc.senseOre(rc.getLocation())>3) {
				rc.mine();
			} else if (state == State.MOVING_TOWARD) {
				MapLocation goHere = findNearbyLocWithMostOre();
				Direction dir = getMoveDir(goHere);

				if (dir != null && rc.canMove(dir))
					rc.move(dir);
				else {
					state = State.MOVING_AWAY;
					goAwayFromHere = rc.getLocation();
				}
			} else if (state == State.MOVING_AWAY) {
				if (rc.getLocation().distanceSquaredTo(goAwayFromHere) >= 6)
					state = State.MOVING_TOWARD;
			}
		}
	}


}