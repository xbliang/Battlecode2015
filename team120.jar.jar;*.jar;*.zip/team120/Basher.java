package team120;

import battlecode.common.*;

public class Basher extends BaseBot {
    public Basher(RobotController rc) {
        super(rc);
    }

    public void execute() throws GameActionException {
        
    }
}