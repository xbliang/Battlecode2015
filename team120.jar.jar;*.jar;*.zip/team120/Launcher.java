package team120;

import battlecode.common.*;

public class Launcher extends BaseBot {
    public Launcher(RobotController rc) {
        super(rc);
    }

    public void execute() throws GameActionException {
        
    }
}