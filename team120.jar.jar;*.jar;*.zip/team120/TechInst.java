package team120;

import battlecode.common.*;

public class TechInst extends BaseBot {
    public TechInst(RobotController rc) {
        super(rc);
    }

    public void execute() throws GameActionException {
        
    }
}