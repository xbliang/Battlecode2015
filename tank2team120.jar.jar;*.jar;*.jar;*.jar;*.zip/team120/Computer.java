package team120;

import battlecode.common.*;

public class Computer extends BaseBot {
    public Computer(RobotController rc) {
        super(rc);
    }

    public void execute() throws GameActionException {
        
    }
}