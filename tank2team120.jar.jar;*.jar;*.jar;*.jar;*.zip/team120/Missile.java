package team120;

import battlecode.common.*;

public class Missile extends BaseBot {
    public Missile(RobotController rc) {
        super(rc);
    }

    public void execute() throws GameActionException {
        
    }
}