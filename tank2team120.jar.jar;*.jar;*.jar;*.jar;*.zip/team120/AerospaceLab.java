package team120;

import battlecode.common.*;

public class AerospaceLab extends BaseBot {
    public AerospaceLab(RobotController rc) {
        super(rc);
    }

    public void execute() throws GameActionException {
        
    }
}