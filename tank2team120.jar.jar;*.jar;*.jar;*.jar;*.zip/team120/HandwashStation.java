package team120;

import battlecode.common.*;

public class HandwashStation extends BaseBot {
    public HandwashStation(RobotController rc) {
        super(rc);
    }

    public void execute() throws GameActionException {
        
    }
}