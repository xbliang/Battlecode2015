package team120;

import battlecode.common.*;

public class TankFactory extends BaseBot {
    public TankFactory(RobotController rc) {
    	super(rc);
    	System.out.println("THIS IS A TANK FACTORY");
    }

    public void execute() throws GameActionException {
    	spawnAndBroadcast(RobotType.TANK);
    }
}