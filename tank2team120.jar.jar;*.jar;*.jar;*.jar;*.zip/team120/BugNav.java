package team120;

import battlecode.common.*;

public class BugNav {
	private RobotController rc;
	private MapLocation myHQ;
	private MapLocation enemyHQ;
	private MapLocation[] myTowers;
	private MapLocation[] enemyTowers;
	
	private boolean movingToLocation, bugging, buggingClockwise;
	private MapLocation startLocation, endLocation;
	private MapLocation[] mLineLocations;
	private int farthestProgress; // progress along array of m-line locations
	private Direction lastMoveDir; // direction of most recent move
	private Direction queuedDir;
	
	private boolean avoidEnemyTowers;
	
	public BugNav(RobotController myrc, boolean avoidTowers) {
		rc = myrc;
		avoidEnemyTowers = avoidTowers;
		myHQ = rc.senseHQLocation();
		enemyHQ = rc.senseEnemyHQLocation();
		enemyTowers = rc.senseTowerLocations();
		enemyTowers = rc.senseEnemyTowerLocations();
	}
	
	public TerrainTile senseTerrainInDirection(Direction dir) {
		return rc.senseTerrainTile(rc.getLocation().add(dir));
	}
	
	public boolean canTraverse(Direction dir) {
		// TODO: don't treat HQs and towers as traversable, in general
		//return (senseTerrainInDirection(dir).isTraversable() && !rc.getLocation().add(dir).equals(myHQ));
		
		if (!rc.canMove(dir)) {
			return false;
		}
		
		// avoid enemy towers and HQ, if applicable
		boolean safe = true;
		
		if (avoidEnemyTowers) {
			MapLocation myLoc = rc.getLocation();
			if (rc.canMove(dir)) {            	
				for (int i = 0; i < enemyTowers.length + 1; i++) {
					MapLocation enemy = (i == enemyTowers.length) ? enemyHQ : enemyTowers[i];
					if (myLoc.add(dir).distanceSquaredTo(enemy) <= 24) {
						safe = false;
					}
				}
			}
		}
		return safe;
	}
	
	private Direction nextBugDirection(Direction prevDir, boolean clockwise) {
		Direction nextDir;
		
		if (clockwise) {
			nextDir = prevDir.rotateRight().rotateRight();
		}
		else {
			nextDir = prevDir.rotateLeft().rotateLeft();
		}
		
		while(!canTraverse(nextDir)) {
			if (senseTerrainInDirection(nextDir) == TerrainTile.OFF_MAP) {
				// if we hit the edge of the map, turn around
				buggingClockwise = !buggingClockwise;
				return prevDir.opposite();
			}
			else {
				if (clockwise) {
					nextDir = nextDir.rotateLeft();
				}
				else {
					nextDir = nextDir.rotateRight();
				}
			}
		}
		return nextDir;
	}

	private MapLocation[] getMLineLocations(MapLocation start, MapLocation end) {
		// returns array of locations in m-line (only approximately straight)
		int dx = Math.abs(end.x - start.x);
		int dy = Math.abs(end.y - start.y);
		int numLocs = Math.max(dx,dy) + 1;
		MapLocation[] locs = new MapLocation[numLocs];

		MapLocation currLoc = start;
		for (int i=0; i<numLocs; i++) {
			locs[i] = currLoc;
			//System.out.println(currLoc.x + ", " + currLoc.y);
			currLoc = currLoc.add(currLoc.directionTo(end));
		}
		return locs;
	}

	public Direction nextMoveDirection() {
		// straightforward implementation of bug2 algorithm
		MapLocation currLocation = rc.getLocation();
		
		//System.out.println("entering nextMoveDirection from " + currLocation.x + ", " + currLocation.y);
		if (bugging && buggingClockwise) {
			//System.out.println("bugging clockwise");
		}
		else if (bugging && !buggingClockwise) {
			//System.out.println("bugging counterclockwise");
		}

		if (bugging) {
			// stop bugging if we're on the straight line, strictly farther than we've been before
			// TODO: binary search
			for (int i=farthestProgress+1; i<mLineLocations.length; i++) {
				if (currLocation.equals(mLineLocations[i])) {
					farthestProgress = i;
					bugging = false;
					break;
				}
			}
		}
		
//		if (bugging) {
//			System.out.println("bugging still on");
//		}

		// otherwise, if we just moved diagonally, check if we're adjacent to the m-line and move there
		if (bugging) {
			if (lastMoveDir == Direction.NORTH_EAST || lastMoveDir == Direction.NORTH_WEST
					|| lastMoveDir == Direction.SOUTH_EAST || lastMoveDir == Direction.SOUTH_WEST ) {
				
				// check if we're at a 2x2 intersection of our path and the m-line (the only kind that matters (?))
				Direction[] tryDirs = {lastMoveDir.opposite().rotateLeft(), lastMoveDir.opposite().rotateRight()};
				MapLocation[] tryLocs = {currLocation.add(tryDirs[0]), currLocation.add(tryDirs[1])};
				
				boolean found2x2Intersection = false;
				Direction dirToMLine = Direction.NONE; // the farther one in the 2x2 square
				for (int i=farthestProgress+1; i<mLineLocations.length-1; i++) {
					if (mLineLocations[i].equals(tryLocs[0])) {
						if (mLineLocations[i+1].equals(tryLocs[1])) {
							found2x2Intersection = true;
							farthestProgress = i;
							dirToMLine = tryDirs[1];
						}
						break;
					}
					else if (mLineLocations[i].equals(tryLocs[1])) {
						if (mLineLocations[i+1].equals(tryLocs[0])) {
							found2x2Intersection = true;
							farthestProgress = i;
							dirToMLine = tryDirs[0];
						}
						break;
					}
				}
				
				if (found2x2Intersection) {
					//System.out.println("found 2x2 intersection");
					if (canTraverse(dirToMLine)) {
						// get back on the m-line if it's not blocked
						bugging = false;
						return dirToMLine;
					}
					else {
						// start bugging in opposite direction
						//System.out.println("reversing bugging direction");
						buggingClockwise = !buggingClockwise;
					}
				}
			}
		}

		// now figure out how to move in all other cases
		if (!bugging) {
			if (canTraverse(currLocation.directionTo(endLocation))) {
				// continue motion on m-line
				farthestProgress++;
				return currLocation.directionTo(endLocation);
			}
			else {
				// obstacle detected, so start bugging
				bugging = true;
				
				// decide whether to bug clockwise or counterclockwise, based on distance to goal
				
				Direction clockwiseTryDir = currLocation.directionTo(endLocation).rotateLeft();
				while (!canTraverse(clockwiseTryDir)) {
					clockwiseTryDir = clockwiseTryDir.rotateLeft();
				}
				MapLocation clockwiseTryLoc = currLocation.add(clockwiseTryDir);
				
				Direction counterclockwiseTryDir = currLocation.directionTo(endLocation).rotateRight();
				while (!canTraverse(counterclockwiseTryDir)) {
					counterclockwiseTryDir = counterclockwiseTryDir.rotateRight();
				}
				MapLocation counterclockwiseTryLoc = currLocation.add(counterclockwiseTryDir);
				
				if (counterclockwiseTryLoc.distanceSquaredTo(endLocation) >= clockwiseTryLoc.distanceSquaredTo(endLocation)) {
					buggingClockwise = true;
					return clockwiseTryDir;
				}
				else {
					buggingClockwise = false;
					return counterclockwiseTryDir;
				}
			}
		}
		else {
			return nextBugDirection(lastMoveDir, buggingClockwise);
		}
	}

	public void moveTo(MapLocation dest) throws GameActionException {

		if (rc.getLocation().equals(dest)) {
			movingToLocation = false;
			return;
		}

		if (!dest.equals(endLocation)) {
			// reset navigation data when moving somewhere new
			movingToLocation = true;
			bugging = false;
			queuedDir = Direction.NONE;
			startLocation = rc.getLocation();
			endLocation = dest;
			mLineLocations = getMLineLocations(startLocation, endLocation);
			farthestProgress = 0;
		}

		if (queuedDir == Direction.NONE) {
			queuedDir = nextMoveDirection();
			//System.out.println(queuedDir);
		}
		
		if (rc.isCoreReady() && rc.canMove(queuedDir)) {
			rc.move(queuedDir);
			lastMoveDir = queuedDir;
			queuedDir = Direction.NONE;
		}
	}
	
	public boolean isMovingToLocation() {
		return movingToLocation;
	}
	
	public Direction facing() {
		return lastMoveDir;
	}
}